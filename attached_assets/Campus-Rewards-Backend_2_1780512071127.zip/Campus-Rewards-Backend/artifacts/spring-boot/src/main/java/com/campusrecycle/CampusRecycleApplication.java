package com.campusrecycle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusRecycleApplication {
    public static void main(String[] args) {
        SpringApplication.run(CampusRecycleApplication.class, args);
    }
}
